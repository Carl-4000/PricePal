import { base44 } from './base44Client';


export const Store = base44.entities.Store;

export const Product = base44.entities.Product;

export const PriceHistory = base44.entities.PriceHistory;



// auth sdk:
export const User = base44.auth;