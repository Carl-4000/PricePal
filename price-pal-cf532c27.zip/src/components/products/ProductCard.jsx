import React, { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Trash2, Edit, TrendingUp } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";

import EditProductDialog from "./EditProductDialog";

export default function ProductCard({ product, storeId, onDelete }) {
  const navigate = useNavigate();
  const [showEditDialog, setShowEditDialog] = useState(false);

  const categoryColors = {
    produce: "bg-green-100 text-green-800",
    dairy: "bg-blue-100 text-blue-800",
    meat: "bg-red-100 text-red-800",
    bakery: "bg-orange-100 text-orange-800",
    pantry: "bg-yellow-100 text-yellow-800",
    frozen: "bg-cyan-100 text-cyan-800",
    beverages: "bg-purple-100 text-purple-800",
    snacks: "bg-pink-100 text-pink-800",
    household: "bg-gray-100 text-gray-800",
    other: "bg-slate-100 text-slate-800",
  };

  return (
    <>
      <Card className="bg-white border-0 shadow-sm hover:shadow-md transition-all duration-300 overflow-hidden group">
        {product.image_url && (
          <div className="aspect-video overflow-hidden bg-gray-100">
            <img
              src={product.image_url}
              alt={product.name}
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
            />
          </div>
        )}
        <CardContent className="p-6">
          <div className="flex justify-between items-start mb-3">
            <div className="flex-1">
              <h3 className="text-lg font-bold mb-2" style={{ color: "hsl(var(--charcoal))" }}>
                {product.name}
              </h3>
              {product.category && (
                <Badge className={`${categoryColors[product.category]} border-0`}>
                  {product.category}
                </Badge>
              )}
            </div>
          </div>

          {product.description && (
            <p className="text-sm opacity-70 mb-4 line-clamp-2">{product.description}</p>
          )}

          <div className="flex items-center justify-between mb-4">
            <div>
              <p className="text-sm opacity-60 mb-1">Current Price</p>
              <p className="text-3xl font-bold" style={{ color: "hsl(var(--sage))" }}>
                ${product.current_price.toFixed(2)}
              </p>
            </div>
            <Button
              variant="outline"
              size="icon"
              onClick={() => navigate(createPageUrl("PriceTrends") + "?product=" + product.id)}
              className="rounded-xl"
              style={{ borderColor: "hsl(var(--sage) / 0.3)" }}
            >
              <TrendingUp className="w-4 h-4" style={{ color: "hsl(var(--sage))" }} />
            </Button>
          </div>

          <div className="flex gap-2">
            <Button
              variant="outline"
              className="flex-1 rounded-xl"
              onClick={() => setShowEditDialog(true)}
            >
              <Edit className="w-4 h-4 mr-2" />
              Edit
            </Button>
            <Button
              variant="outline"
              size="icon"
              onClick={() => {
                if (confirm('Delete this product and its price history?')) {
                  onDelete();
                }
              }}
              className="rounded-xl border-red-200 text-red-600 hover:bg-red-50"
            >
              <Trash2 className="w-4 h-4" />
            </Button>
          </div>
        </CardContent>
      </Card>

      <EditProductDialog
        open={showEditDialog}
        onClose={() => setShowEditDialog(false)}
        product={product}
        storeId={storeId}
      />
    </>
  );
}