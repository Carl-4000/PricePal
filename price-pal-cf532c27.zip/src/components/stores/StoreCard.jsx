import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { MapPin, ArrowRight, Trash2 } from "lucide-react";

export default function StoreCard({ store, onDelete }) {
  const navigate = useNavigate();

  return (
    <Card className="bg-white border-0 shadow-sm hover:shadow-md transition-all duration-300 overflow-hidden group">
      <div className="h-2" style={{ backgroundColor: "hsl(var(--sage))" }} />
      <CardContent className="p-6">
        <div className="flex justify-between items-start mb-4">
          <div className="flex-1">
            <h3 className="text-xl font-bold mb-2 group-hover:text-current transition-colors" style={{ color: "hsl(var(--charcoal))" }}>
              {store.name}
            </h3>
            {store.address && (
              <div className="flex items-start gap-2 opacity-70">
                <MapPin className="w-4 h-4 mt-0.5 flex-shrink-0" />
                <span className="text-sm">{store.address}</span>
              </div>
            )}
          </div>
        </div>

        <div className="space-y-2 mb-6">
          {store.phone && (
            <p className="text-sm opacity-70">📞 {store.phone}</p>
          )}
          {store.hours && (
            <p className="text-sm opacity-70">🕒 {store.hours}</p>
          )}
        </div>

        <div className="flex gap-2">
          <Button
            className="flex-1 rounded-xl"
            style={{ backgroundColor: "hsl(var(--sage))" }}
            onClick={() => navigate(createPageUrl("StoreDetail") + "?id=" + store.id)}
          >
            View Details
            <ArrowRight className="w-4 h-4 ml-2" />
          </Button>
          <Button
            variant="outline"
            size="icon"
            onClick={(e) => {
              e.stopPropagation();
              if (confirm('Delete this store and all its products?')) {
                onDelete();
              }
            }}
            className="rounded-xl border-red-200 text-red-600 hover:bg-red-50"
          >
            <Trash2 className="w-4 h-4" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}