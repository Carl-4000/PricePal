import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Plus, Search } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";

import StoreCard from "../components/stores/StoreCard";
import AddStoreDialog from "../components/stores/AddStoreDialog";

export default function Stores() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [searchQuery, setSearchQuery] = useState("");
  const [showAddDialog, setShowAddDialog] = useState(false);

  const { data: stores, isLoading } = useQuery({
    queryKey: ['stores'],
    queryFn: () => base44.entities.Store.list('-created_date'),
    initialData: [],
  });

  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    if (urlParams.get('action') === 'add') {
      setShowAddDialog(true);
    }
  }, []);

  const deleteStoreMutation = useMutation({
    mutationFn: (storeId) => base44.entities.Store.delete(storeId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['stores'] });
    },
  });

  const filteredStores = stores.filter(store =>
    store.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    store.address?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="p-6 md:p-10 max-w-7xl mx-auto">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
        <div>
          <h1 className="text-3xl font-bold mb-2" style={{ color: "hsl(var(--charcoal))" }}>
            Store Directory
          </h1>
          <p className="opacity-70">Manage your tracked stores and products</p>
        </div>
        <Button 
          onClick={() => setShowAddDialog(true)}
          className="rounded-xl"
          style={{ backgroundColor: "hsl(var(--sage))" }}
        >
          <Plus className="w-5 h-5 mr-2" />
          Add Store
        </Button>
      </div>

      <div className="mb-8">
        <div className="relative max-w-md">
          <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5 opacity-40" />
          <Input
            placeholder="Search stores..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-12 h-12 rounded-xl border-2"
            style={{ borderColor: "hsl(var(--sage) / 0.2)" }}
          />
        </div>
      </div>

      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[1, 2, 3].map((i) => (
            <div key={i} className="h-64 bg-white rounded-2xl animate-pulse" />
          ))}
        </div>
      ) : filteredStores.length === 0 ? (
        <div className="text-center py-20">
          <div className="w-20 h-20 rounded-full mx-auto mb-4 flex items-center justify-center" style={{ backgroundColor: "hsl(var(--sage-light))" }}>
            <Search className="w-10 h-10" style={{ color: "hsl(var(--sage))" }} />
          </div>
          <h3 className="text-xl font-semibold mb-2" style={{ color: "hsl(var(--charcoal))" }}>
            {searchQuery ? "No stores found" : "No stores yet"}
          </h3>
          <p className="opacity-60 mb-6">
            {searchQuery ? "Try a different search term" : "Start by adding your first store"}
          </p>
          {!searchQuery && (
            <Button 
              onClick={() => setShowAddDialog(true)}
              className="rounded-xl"
              style={{ backgroundColor: "hsl(var(--sage))" }}
            >
              <Plus className="w-5 h-5 mr-2" />
              Add Your First Store
            </Button>
          )}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredStores.map((store) => (
            <StoreCard
              key={store.id}
              store={store}
              onDelete={() => deleteStoreMutation.mutate(store.id)}
            />
          ))}
        </div>
      )}

      <AddStoreDialog
        open={showAddDialog}
        onClose={() => setShowAddDialog(false)}
      />
    </div>
  );
}