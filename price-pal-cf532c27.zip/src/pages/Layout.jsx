
import React from "react";
import { Link, useLocation } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Store, Map, LayoutDashboard, TrendingUp } from "lucide-react";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarHeader,
  SidebarProvider,
  SidebarTrigger,
} from "@/components/ui/sidebar";

const navigationItems = [
  {
    title: "Dashboard",
    url: createPageUrl("Dashboard"),
    icon: LayoutDashboard,
  },
  {
    title: "Stores",
    url: createPageUrl("Stores"),
    icon: Store,
  },
  {
    title: "Map View",
    url: createPageUrl("MapView"),
    icon: Map,
  },
  {
    title: "Price Trends",
    url: createPageUrl("PriceTrends"),
    icon: TrendingUp,
  },
];

export default function Layout({ children, currentPageName }) {
  const location = useLocation();

  return (
    <SidebarProvider>
      <style>{`
        :root {
          --sage: 135 35% 55%;
          --sage-light: 135 35% 95%;
          --cream: 40 20% 96%;
          --charcoal: 0 0% 20%;
          --accent: 160 45% 50%;
        }
      `}</style>
      <div className="min-h-screen flex w-full" style={{ backgroundColor: "hsl(var(--cream))" }}>
        <Sidebar className="border-r" style={{ borderColor: "hsl(var(--sage) / 0.2)" }}>
          <SidebarHeader className="border-b p-6" style={{ borderColor: "hsl(var(--sage) / 0.2)" }}>
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl flex items-center justify-center" style={{ backgroundColor: "hsl(var(--sage))" }}>
                <Store className="w-6 h-6 text-white" />
              </div>
              <div>
                <h2 className="font-semibold text-lg" style={{ color: "hsl(var(--charcoal))" }}>PriceTrack</h2>
                <p className="text-xs opacity-60">Smart Grocery Directory</p>
              </div>
            </div>
          </SidebarHeader>
          
          <SidebarContent className="p-3">
            <SidebarGroup>
              <SidebarGroupLabel className="text-xs font-medium uppercase tracking-wider px-3 py-2 opacity-60">
                Navigation
              </SidebarGroupLabel>
              <SidebarGroupContent>
                <SidebarMenu>
                  {navigationItems.map((item) => (
                    <SidebarMenuItem key={item.title}>
                      <SidebarMenuButton 
                        asChild 
                        className={`rounded-xl transition-all duration-300 mb-1 ${
                          location.pathname === item.url 
                            ? 'text-white' 
                            : 'hover:bg-white/50'
                        }`}
                        style={location.pathname === item.url ? { backgroundColor: "hsl(var(--sage))" } : {}}
                      >
                        <Link to={item.url} className="flex items-center gap-3 px-4 py-3">
                          <item.icon className="w-5 h-5" />
                          <span className="font-medium">{item.title}</span>
                        </Link>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                  ))}
                </SidebarMenu>
              </SidebarGroupContent>
            </SidebarGroup>
          </SidebarContent>
        </Sidebar>

        <main className="flex-1 flex flex-col">
          <header className="bg-white border-b px-6 py-4 md:hidden" style={{ borderColor: "hsl(var(--sage) / 0.2)" }}>
            <div className="flex items-center gap-4">
              <SidebarTrigger className="hover:bg-gray-100 p-2 rounded-xl transition-colors duration-200" />
              <h1 className="text-xl font-semibold">PriceTrack</h1>
            </div>
          </header>

          <div className="flex-1 overflow-auto">
            {children}
          </div>
        </main>
      </div>
    </SidebarProvider>
  );
}
