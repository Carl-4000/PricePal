import React from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Store, Package, TrendingDown, TrendingUp, Plus, ArrowRight } from "lucide-react";
import { format } from "date-fns";

export default function Dashboard() {
  const { data: stores, isLoading: storesLoading } = useQuery({
    queryKey: ['stores'],
    queryFn: () => base44.entities.Store.list(),
    initialData: [],
  });

  const { data: products, isLoading: productsLoading } = useQuery({
    queryKey: ['products'],
    queryFn: () => base44.entities.Product.list('-updated_date'),
    initialData: [],
  });

  const { data: priceHistory, isLoading: historyLoading } = useQuery({
    queryKey: ['priceHistory'],
    queryFn: () => base44.entities.PriceHistory.list('-date', 10),
    initialData: [],
  });

  const recentChanges = priceHistory.slice(0, 5);

  return (
    <div className="p-6 md:p-10 max-w-7xl mx-auto">
      <div className="mb-10">
        <h1 className="text-4xl font-bold mb-2" style={{ color: "hsl(var(--charcoal))" }}>
          Welcome to PriceTrack
        </h1>
        <p className="text-lg opacity-70">Track prices, save money, shop smarter</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-10">
        <Card className="bg-white border-0 shadow-sm hover:shadow-md transition-shadow duration-300">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-sm font-medium opacity-70">Total Stores</CardTitle>
              <div className="w-10 h-10 rounded-xl flex items-center justify-center" style={{ backgroundColor: "hsl(var(--sage-light))" }}>
                <Store className="w-5 h-5" style={{ color: "hsl(var(--sage))" }} />
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold" style={{ color: "hsl(var(--charcoal))" }}>
              {stores.length}
            </div>
            <Link to={createPageUrl("Stores")}>
              <Button variant="link" className="px-0 mt-2" style={{ color: "hsl(var(--sage))" }}>
                View all <ArrowRight className="w-4 h-4 ml-1" />
              </Button>
            </Link>
          </CardContent>
        </Card>

        <Card className="bg-white border-0 shadow-sm hover:shadow-md transition-shadow duration-300">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-sm font-medium opacity-70">Products Tracked</CardTitle>
              <div className="w-10 h-10 rounded-xl flex items-center justify-center" style={{ backgroundColor: "hsl(var(--sage-light))" }}>
                <Package className="w-5 h-5" style={{ color: "hsl(var(--sage))" }} />
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold" style={{ color: "hsl(var(--charcoal))" }}>
              {products.length}
            </div>
            <p className="text-sm opacity-60 mt-2">Across all stores</p>
          </CardContent>
        </Card>

        <Card className="bg-white border-0 shadow-sm hover:shadow-md transition-shadow duration-300">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-sm font-medium opacity-70">Price Changes</CardTitle>
              <div className="w-10 h-10 rounded-xl flex items-center justify-center" style={{ backgroundColor: "hsl(var(--sage-light))" }}>
                <TrendingUp className="w-5 h-5" style={{ color: "hsl(var(--sage))" }} />
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold" style={{ color: "hsl(var(--charcoal))" }}>
              {priceHistory.length}
            </div>
            <Link to={createPageUrl("PriceTrends")}>
              <Button variant="link" className="px-0 mt-2" style={{ color: "hsl(var(--sage))" }}>
                View trends <ArrowRight className="w-4 h-4 ml-1" />
              </Button>
            </Link>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="bg-white border-0 shadow-sm">
          <CardHeader className="border-b pb-4" style={{ borderColor: "hsl(var(--sage) / 0.1)" }}>
            <CardTitle className="flex items-center justify-between">
              <span>Recent Price Changes</span>
              <Link to={createPageUrl("PriceTrends")}>
                <Button variant="ghost" size="sm" style={{ color: "hsl(var(--sage))" }}>
                  View all
                </Button>
              </Link>
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-6">
            {recentChanges.length === 0 ? (
              <p className="text-center opacity-60 py-8">No price changes yet</p>
            ) : (
              <div className="space-y-4">
                {recentChanges.map((change) => {
                  const product = products.find(p => p.id === change.product_id);
                  return (
                    <div key={change.id} className="flex items-center justify-between py-3 border-b last:border-0" style={{ borderColor: "hsl(var(--sage) / 0.1)" }}>
                      <div>
                        <p className="font-medium">{product?.name || 'Unknown Product'}</p>
                        <p className="text-sm opacity-60">{format(new Date(change.date), 'MMM d, yyyy')}</p>
                      </div>
                      <div className="text-right">
                        <p className="font-semibold text-lg" style={{ color: "hsl(var(--sage))" }}>
                          ${change.price.toFixed(2)}
                        </p>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </CardContent>
        </Card>

        <Card className="bg-white border-0 shadow-sm">
          <CardHeader className="border-b pb-4" style={{ borderColor: "hsl(var(--sage) / 0.1)" }}>
            <CardTitle>Quick Actions</CardTitle>
          </CardHeader>
          <CardContent className="pt-6">
            <div className="space-y-3">
              <Link to={createPageUrl("Stores") + "?action=add"}>
                <Button className="w-full justify-start text-left h-auto py-4 rounded-xl" style={{ backgroundColor: "hsl(var(--sage))" }}>
                  <Plus className="w-5 h-5 mr-3" />
                  <div>
                    <div className="font-semibold">Add New Store</div>
                    <div className="text-sm opacity-80">Start tracking a new location</div>
                  </div>
                </Button>
              </Link>
              
              <Link to={createPageUrl("MapView")}>
                <Button variant="outline" className="w-full justify-start text-left h-auto py-4 rounded-xl border-2" style={{ borderColor: "hsl(var(--sage) / 0.3)" }}>
                  <div className="w-10 h-10 rounded-lg flex items-center justify-center mr-3" style={{ backgroundColor: "hsl(var(--sage-light))" }}>
                    <Store className="w-5 h-5" style={{ color: "hsl(var(--sage))" }} />
                  </div>
                  <div>
                    <div className="font-semibold" style={{ color: "hsl(var(--charcoal))" }}>View Store Map</div>
                    <div className="text-sm opacity-60">See all locations</div>
                  </div>
                </Button>
              </Link>

              <Link to={createPageUrl("Stores")}>
                <Button variant="outline" className="w-full justify-start text-left h-auto py-4 rounded-xl border-2" style={{ borderColor: "hsl(var(--sage) / 0.3)" }}>
                  <div className="w-10 h-10 rounded-lg flex items-center justify-center mr-3" style={{ backgroundColor: "hsl(var(--sage-light))" }}>
                    <Package className="w-5 h-5" style={{ color: "hsl(var(--sage))" }} />
                  </div>
                  <div>
                    <div className="font-semibold" style={{ color: "hsl(var(--charcoal))" }}>Browse Stores</div>
                    <div className="text-sm opacity-60">View all tracked stores</div>
                  </div>
                </Button>
              </Link>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}