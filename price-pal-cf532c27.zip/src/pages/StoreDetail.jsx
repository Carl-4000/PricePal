import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { ArrowLeft, Plus, MapPin, Phone, Mail, Globe, Clock, Edit, Trash2 } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

import ProductCard from "../components/products/ProductCard";
import AddProductDialog from "../components/products/AddProductDialog";
import EditStoreDialog from "../components/stores/EditStoreDialog";

export default function StoreDetail() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [showAddProduct, setShowAddProduct] = useState(false);
  const [showEditStore, setShowEditStore] = useState(false);
  
  const urlParams = new URLSearchParams(window.location.search);
  const storeId = urlParams.get('id');

  const { data: store, isLoading: storeLoading } = useQuery({
    queryKey: ['store', storeId],
    queryFn: async () => {
      const stores = await base44.entities.Store.list();
      return stores.find(s => s.id === storeId);
    },
    enabled: !!storeId,
  });

  const { data: products, isLoading: productsLoading } = useQuery({
    queryKey: ['products', storeId],
    queryFn: () => base44.entities.Product.filter({ store_id: storeId }, '-created_date'),
    initialData: [],
    enabled: !!storeId,
  });

  const deleteStoreMutation = useMutation({
    mutationFn: (id) => base44.entities.Store.delete(id),
    onSuccess: () => {
      navigate(createPageUrl("Stores"));
    },
  });

  const deleteProductMutation = useMutation({
    mutationFn: (id) => base44.entities.Product.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['products', storeId] });
    },
  });

  if (storeLoading) {
    return (
      <div className="p-6 md:p-10">
        <div className="animate-pulse space-y-4">
          <div className="h-8 bg-gray-200 rounded w-1/4" />
          <div className="h-64 bg-gray-200 rounded" />
        </div>
      </div>
    );
  }

  if (!store) {
    return (
      <div className="p-6 md:p-10 text-center">
        <h2 className="text-2xl font-bold mb-4">Store not found</h2>
        <Button onClick={() => navigate(createPageUrl("Stores"))}>
          Go back to stores
        </Button>
      </div>
    );
  }

  return (
    <div className="p-6 md:p-10 max-w-7xl mx-auto">
      <Button
        variant="ghost"
        onClick={() => navigate(createPageUrl("Stores"))}
        className="mb-6 rounded-xl"
      >
        <ArrowLeft className="w-4 h-4 mr-2" />
        Back to Stores
      </Button>

      <Card className="bg-white border-0 shadow-sm mb-8">
        <CardHeader className="border-b pb-6" style={{ borderColor: "hsl(var(--sage) / 0.1)" }}>
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
            <div>
              <CardTitle className="text-3xl font-bold mb-2" style={{ color: "hsl(var(--charcoal))" }}>
                {store.name}
              </CardTitle>
              {store.address && (
                <div className="flex items-center gap-2 opacity-70">
                  <MapPin className="w-4 h-4" />
                  <span>{store.address}</span>
                </div>
              )}
            </div>
            <div className="flex gap-2">
              <Button
                variant="outline"
                onClick={() => setShowEditStore(true)}
                className="rounded-xl"
              >
                <Edit className="w-4 h-4 mr-2" />
                Edit
              </Button>
              <Button
                variant="outline"
                onClick={() => {
                  if (confirm('Are you sure you want to delete this store? This will also delete all products.')) {
                    deleteStoreMutation.mutate(store.id);
                  }
                }}
                className="rounded-xl text-red-600 border-red-200 hover:bg-red-50"
              >
                <Trash2 className="w-4 h-4 mr-2" />
                Delete
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent className="pt-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {store.phone && (
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 rounded-xl flex items-center justify-center" style={{ backgroundColor: "hsl(var(--sage-light))" }}>
                  <Phone className="w-5 h-5" style={{ color: "hsl(var(--sage))" }} />
                </div>
                <div>
                  <p className="text-sm opacity-60 mb-1">Phone</p>
                  <p className="font-medium">{store.phone}</p>
                </div>
              </div>
            )}
            {store.email && (
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 rounded-xl flex items-center justify-center" style={{ backgroundColor: "hsl(var(--sage-light))" }}>
                  <Mail className="w-5 h-5" style={{ color: "hsl(var(--sage))" }} />
                </div>
                <div>
                  <p className="text-sm opacity-60 mb-1">Email</p>
                  <p className="font-medium">{store.email}</p>
                </div>
              </div>
            )}
            {store.website && (
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 rounded-xl flex items-center justify-center" style={{ backgroundColor: "hsl(var(--sage-light))" }}>
                  <Globe className="w-5 h-5" style={{ color: "hsl(var(--sage))" }} />
                </div>
                <div>
                  <p className="text-sm opacity-60 mb-1">Website</p>
                  <a href={store.website} target="_blank" rel="noopener noreferrer" className="font-medium hover:underline" style={{ color: "hsl(var(--sage))" }}>
                    Visit Website
                  </a>
                </div>
              </div>
            )}
            {store.hours && (
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 rounded-xl flex items-center justify-center" style={{ backgroundColor: "hsl(var(--sage-light))" }}>
                  <Clock className="w-5 h-5" style={{ color: "hsl(var(--sage))" }} />
                </div>
                <div>
                  <p className="text-sm opacity-60 mb-1">Hours</p>
                  <p className="font-medium whitespace-pre-line">{store.hours}</p>
                </div>
              </div>
            )}
          </div>
          {store.notes && (
            <div className="mt-6 p-4 rounded-xl" style={{ backgroundColor: "hsl(var(--sage-light))" }}>
              <p className="text-sm font-medium mb-1">Notes</p>
              <p className="opacity-80">{store.notes}</p>
            </div>
          )}
        </CardContent>
      </Card>

      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold" style={{ color: "hsl(var(--charcoal))" }}>
          Products ({products.length})
        </h2>
        <Button 
          onClick={() => setShowAddProduct(true)}
          className="rounded-xl"
          style={{ backgroundColor: "hsl(var(--sage))" }}
        >
          <Plus className="w-5 h-5 mr-2" />
          Add Product
        </Button>
      </div>

      {productsLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[1, 2, 3].map((i) => (
            <div key={i} className="h-64 bg-white rounded-2xl animate-pulse" />
          ))}
        </div>
      ) : products.length === 0 ? (
        <Card className="bg-white border-0 shadow-sm">
          <CardContent className="py-20 text-center">
            <div className="w-20 h-20 rounded-full mx-auto mb-4 flex items-center justify-center" style={{ backgroundColor: "hsl(var(--sage-light))" }}>
              <Plus className="w-10 h-10" style={{ color: "hsl(var(--sage))" }} />
            </div>
            <h3 className="text-xl font-semibold mb-2" style={{ color: "hsl(var(--charcoal))" }}>
              No products yet
            </h3>
            <p className="opacity-60 mb-6">Start adding products to track their prices</p>
            <Button 
              onClick={() => setShowAddProduct(true)}
              className="rounded-xl"
              style={{ backgroundColor: "hsl(var(--sage))" }}
            >
              <Plus className="w-5 h-5 mr-2" />
              Add First Product
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {products.map((product) => (
            <ProductCard
              key={product.id}
              product={product}
              storeId={storeId}
              onDelete={() => deleteProductMutation.mutate(product.id)}
            />
          ))}
        </div>
      )}

      <AddProductDialog
        open={showAddProduct}
        onClose={() => setShowAddProduct(false)}
        storeId={storeId}
      />

      <EditStoreDialog
        open={showEditStore}
        onClose={() => setShowEditStore(false)}
        store={store}
      />
    </div>
  );
}