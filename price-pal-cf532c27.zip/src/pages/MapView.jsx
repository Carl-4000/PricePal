import React from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { MapContainer, TileLayer, Marker, Popup } from "react-leaflet";
import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Store, ArrowRight } from "lucide-react";
import "leaflet/dist/leaflet.css";
import L from "leaflet";

delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: "https://unpkg.com/leaflet@1.7.1/dist/images/marker-icon-2x.png",
  iconUrl: "https://unpkg.com/leaflet@1.7.1/dist/images/marker-icon.png",
  shadowUrl: "https://unpkg.com/leaflet@1.7.1/dist/images/marker-shadow.png",
});

export default function MapView() {
  const navigate = useNavigate();

  const { data: stores, isLoading } = useQuery({
    queryKey: ['stores'],
    queryFn: () => base44.entities.Store.list(),
    initialData: [],
  });

  const storesWithCoordinates = stores.filter(s => s.latitude && s.longitude);
  
  const defaultCenter = storesWithCoordinates.length > 0
    ? [storesWithCoordinates[0].latitude, storesWithCoordinates[0].longitude]
    : [37.7749, -122.4194];

  return (
    <div className="h-screen flex flex-col">
      <div className="p-6 border-b" style={{ borderColor: "hsl(var(--sage) / 0.2)", backgroundColor: "white" }}>
        <div className="max-w-7xl mx-auto">
          <h1 className="text-3xl font-bold mb-2" style={{ color: "hsl(var(--charcoal))" }}>
            Store Map
          </h1>
          <p className="opacity-70">View all your tracked stores on the map</p>
        </div>
      </div>

      {isLoading ? (
        <div className="flex-1 flex items-center justify-center bg-gray-100">
          <div className="animate-pulse text-center">
            <div className="w-16 h-16 rounded-full mx-auto mb-4" style={{ backgroundColor: "hsl(var(--sage-light))" }} />
            <p className="opacity-60">Loading map...</p>
          </div>
        </div>
      ) : storesWithCoordinates.length === 0 ? (
        <div className="flex-1 flex items-center justify-center bg-gray-100">
          <div className="text-center max-w-md px-6">
            <div className="w-20 h-20 rounded-full mx-auto mb-4 flex items-center justify-center" style={{ backgroundColor: "hsl(var(--sage-light))" }}>
              <Store className="w-10 h-10" style={{ color: "hsl(var(--sage))" }} />
            </div>
            <h3 className="text-xl font-semibold mb-2" style={{ color: "hsl(var(--charcoal))" }}>
              No stores with locations yet
            </h3>
            <p className="opacity-60 mb-6">
              Add stores with coordinates to see them on the map
            </p>
            <Button 
              onClick={() => navigate(createPageUrl("Stores"))}
              className="rounded-xl"
              style={{ backgroundColor: "hsl(var(--sage))" }}
            >
              Go to Stores
            </Button>
          </div>
        </div>
      ) : (
        <div className="flex-1 relative">
          <MapContainer
            center={defaultCenter}
            zoom={12}
            style={{ height: "100%", width: "100%" }}
          >
            <TileLayer
              url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
              attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
            />
            {storesWithCoordinates.map((store) => (
              <Marker
                key={store.id}
                position={[store.latitude, store.longitude]}
              >
                <Popup>
                  <div className="p-2">
                    <h3 className="font-bold text-lg mb-1">{store.name}</h3>
                    {store.address && (
                      <p className="text-sm opacity-70 mb-2">{store.address}</p>
                    )}
                    <Button
                      size="sm"
                      onClick={() => navigate(createPageUrl("StoreDetail") + "?id=" + store.id)}
                      className="w-full rounded-lg mt-2"
                      style={{ backgroundColor: "hsl(var(--sage))" }}
                    >
                      View Details <ArrowRight className="w-3 h-3 ml-1" />
                    </Button>
                  </div>
                </Popup>
              </Marker>
            ))}
          </MapContainer>
        </div>
      )}
    </div>
  );
}