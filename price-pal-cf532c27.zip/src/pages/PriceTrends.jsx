import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import { format } from "date-fns";
import { TrendingUp, TrendingDown } from "lucide-react";

export default function PriceTrends() {
  const [selectedProduct, setSelectedProduct] = useState(null);

  const { data: products } = useQuery({
    queryKey: ['products'],
    queryFn: () => base44.entities.Product.list(),
    initialData: [],
  });

  const { data: stores } = useQuery({
    queryKey: ['stores'],
    queryFn: () => base44.entities.Store.list(),
    initialData: [],
  });

  const { data: priceHistory } = useQuery({
    queryKey: ['priceHistory', selectedProduct],
    queryFn: () => selectedProduct 
      ? base44.entities.PriceHistory.filter({ product_id: selectedProduct }, 'date')
      : base44.entities.PriceHistory.list('date'),
    initialData: [],
  });

  const getChartData = () => {
    if (!selectedProduct || priceHistory.length === 0) return [];
    
    return priceHistory.map(entry => ({
      date: format(new Date(entry.date), 'MMM d'),
      price: entry.price,
      fullDate: format(new Date(entry.date), 'MMM d, yyyy')
    }));
  };

  const getProductInfo = (productId) => {
    const product = products.find(p => p.id === productId);
    const store = stores.find(s => s.id === product?.store_id);
    return { product, store };
  };

  const selectedProductInfo = selectedProduct ? getProductInfo(selectedProduct) : null;
  const chartData = getChartData();

  const priceChange = chartData.length >= 2 
    ? ((chartData[chartData.length - 1].price - chartData[0].price) / chartData[0].price * 100)
    : 0;

  return (
    <div className="p-6 md:p-10 max-w-7xl mx-auto">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2" style={{ color: "hsl(var(--charcoal))" }}>
          Price Trends
        </h1>
        <p className="opacity-70">Track how prices change over time</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
        <Card className="lg:col-span-2 bg-white border-0 shadow-sm">
          <CardHeader className="border-b pb-4" style={{ borderColor: "hsl(var(--sage) / 0.1)" }}>
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
              <CardTitle>Price History</CardTitle>
              <Select value={selectedProduct || ""} onValueChange={setSelectedProduct}>
                <SelectTrigger className="w-full md:w-80 rounded-xl">
                  <SelectValue placeholder="Select a product" />
                </SelectTrigger>
                <SelectContent>
                  {products.map((product) => {
                    const { store } = getProductInfo(product.id);
                    return (
                      <SelectItem key={product.id} value={product.id}>
                        {product.name} - {store?.name}
                      </SelectItem>
                    );
                  })}
                </SelectContent>
              </Select>
            </div>
          </CardHeader>
          <CardContent className="pt-6">
            {!selectedProduct ? (
              <div className="h-80 flex items-center justify-center">
                <p className="opacity-60">Select a product to view price history</p>
              </div>
            ) : chartData.length === 0 ? (
              <div className="h-80 flex items-center justify-center">
                <p className="opacity-60">No price history available for this product</p>
              </div>
            ) : (
              <ResponsiveContainer width="100%" height={320}>
                <LineChart data={chartData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--sage) / 0.2)" />
                  <XAxis 
                    dataKey="date" 
                    stroke="hsl(var(--charcoal) / 0.5)"
                    style={{ fontSize: '12px' }}
                  />
                  <YAxis 
                    stroke="hsl(var(--charcoal) / 0.5)"
                    style={{ fontSize: '12px' }}
                    tickFormatter={(value) => `$${value.toFixed(2)}`}
                  />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: 'white',
                      border: '1px solid hsl(var(--sage) / 0.2)',
                      borderRadius: '12px',
                      padding: '12px'
                    }}
                    formatter={(value) => [`$${value.toFixed(2)}`, 'Price']}
                    labelFormatter={(label, payload) => payload[0]?.payload?.fullDate || label}
                  />
                  <Line 
                    type="monotone" 
                    dataKey="price" 
                    stroke="hsl(var(--sage))" 
                    strokeWidth={3}
                    dot={{ fill: 'hsl(var(--sage))', strokeWidth: 2, r: 5 }}
                    activeDot={{ r: 7 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            )}
          </CardContent>
        </Card>

        <div className="space-y-6">
          {selectedProductInfo?.product && (
            <>
              <Card className="bg-white border-0 shadow-sm">
                <CardHeader className="border-b pb-4" style={{ borderColor: "hsl(var(--sage) / 0.1)" }}>
                  <CardTitle className="text-lg">Product Details</CardTitle>
                </CardHeader>
                <CardContent className="pt-4">
                  <div className="space-y-3">
                    <div>
                      <p className="text-sm opacity-60 mb-1">Name</p>
                      <p className="font-semibold">{selectedProductInfo.product.name}</p>
                    </div>
                    <div>
                      <p className="text-sm opacity-60 mb-1">Store</p>
                      <p className="font-semibold">{selectedProductInfo.store?.name}</p>
                    </div>
                    <div>
                      <p className="text-sm opacity-60 mb-1">Current Price</p>
                      <p className="text-2xl font-bold" style={{ color: "hsl(var(--sage))" }}>
                        ${selectedProductInfo.product.current_price.toFixed(2)}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {chartData.length >= 2 && (
                <Card className="bg-white border-0 shadow-sm">
                  <CardHeader className="border-b pb-4" style={{ borderColor: "hsl(var(--sage) / 0.1)" }}>
                    <CardTitle className="text-lg">Price Change</CardTitle>
                  </CardHeader>
                  <CardContent className="pt-4">
                    <div className="flex items-center gap-3">
                      <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${
                        priceChange >= 0 ? 'bg-red-100' : 'bg-green-100'
                      }`}>
                        {priceChange >= 0 ? (
                          <TrendingUp className="w-6 h-6 text-red-600" />
                        ) : (
                          <TrendingDown className="w-6 h-6 text-green-600" />
                        )}
                      </div>
                      <div>
                        <p className={`text-2xl font-bold ${
                          priceChange >= 0 ? 'text-red-600' : 'text-green-600'
                        }`}>
                          {priceChange >= 0 ? '+' : ''}{priceChange.toFixed(1)}%
                        </p>
                        <p className="text-sm opacity-60">Since first entry</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}
            </>
          )}
        </div>
      </div>

      <Card className="bg-white border-0 shadow-sm">
        <CardHeader className="border-b pb-4" style={{ borderColor: "hsl(var(--sage) / 0.1)" }}>
          <CardTitle>All Price Changes</CardTitle>
        </CardHeader>
        <CardContent className="pt-6">
          <div className="space-y-3">
            {priceHistory.length === 0 ? (
              <p className="text-center opacity-60 py-8">No price history yet</p>
            ) : (
              priceHistory.map((entry) => {
                const { product, store } = getProductInfo(entry.product_id);
                return (
                  <div key={entry.id} className="flex items-center justify-between p-4 rounded-xl border" style={{ borderColor: "hsl(var(--sage) / 0.2)" }}>
                    <div>
                      <p className="font-semibold">{product?.name}</p>
                      <p className="text-sm opacity-60">{store?.name} • {format(new Date(entry.date), 'MMM d, yyyy h:mm a')}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-xl font-bold" style={{ color: "hsl(var(--sage))" }}>
                        ${entry.price.toFixed(2)}
                      </p>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}